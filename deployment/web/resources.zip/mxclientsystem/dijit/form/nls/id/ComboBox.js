//>>built
define("dijit/form/nls/id/ComboBox",({previousMessage:"Pilihan sebelumnya",nextMessage:"Pilihan lain"}));
