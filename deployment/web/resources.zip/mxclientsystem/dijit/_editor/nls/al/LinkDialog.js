//>>built
define("dijit/_editor/nls/al/LinkDialog",{createLinkTitle:"Cilesitë e lidhjes",insertImageTitle:"Cilesitë e Imazhit",url:"URL:",text:"Përshkrim:",target:"Objektivi:",set:"Vendos",currentWindow:"Dritarja Aktuale",parentWindow:"Dritarja prind",topWindow:"Dritarja e sipërme",newWindow:"Dritare e re"});
