//>>built
define("dijit/nls/el/common",({buttonOk:"ΟΚ",buttonCancel:"Ακύρωση",buttonSave:"Αποθήκευση",itemClose:"Κλείσιμο"}));
